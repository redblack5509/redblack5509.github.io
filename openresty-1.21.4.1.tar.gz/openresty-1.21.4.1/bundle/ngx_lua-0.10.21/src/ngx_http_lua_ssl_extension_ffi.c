#ifndef DDEBUG
#define DDEBUG 0
#endif
#include "ddebug.h"


#if (NGX_HTTP_SSL)


#include "ngx_http_ssl_module.h"


#ifdef KOAL_SSL_EXTENSION

int
ngx_http_lua_ffi_ssl_export_keying_material(ngx_http_request_t *r,
    unsigned char *out, size_t olen, const char *label, size_t llen,
    const unsigned char *context, size_t contextlen, int use_context)
{
    ngx_ssl_conn_t          *ssl_conn;

    if (r->connection == NULL || r->connection->ssl == NULL) {
        return NGX_ERROR;
    }

    ssl_conn = r->connection->ssl->connection;
    if (ssl_conn == NULL) {
        return NGX_ERROR;
    }

    if (SSL_export_keying_material(ssl_conn, out, olen, label, llen, context, contextlen, use_context) != 1) {
        return NGX_ERROR;
    }

    return NGX_OK;
}

#endif /* KOAL_SSL_EXTENSION */


#endif /* NGX_HTTP_SSL */
